block - where & wht the vaue & how it's coming

javascript token error