<?php
error_reporting(0);
session_start(); 

	define('DB_SERVER', 'localhost');
	define('DB_USERNAME', 'tech599_zenatten');
	define('DB_PASSWORD', 'Dev@123$');
	define('DB_DATABASE', 'tech599_zenattend');
	define('SITEROOT','http://104.37.185.20/~tech599/tech599.com/johnanil/zenattend');
	define('SITEEMAIL','mike111taylor@gmail.com');


?>