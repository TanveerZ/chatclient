<?php
error_reporting(0);
// Generation of font definition file for tutorial 7
require('../makefont/makefont.php');

MakeFont('GothamBook.ttf','cp1252');
?>
