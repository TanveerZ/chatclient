<form class="about-page" method="post" enctype="multipart/form-data">
<div class="about-box-sc">
<div class="col-xs-3">
<div class="about-title-box">
<h3 class="brand">Infubo</h3>
<a class="btn">New here?</a>
<a class="btn">PROFILE</a>
<a class="btn">SIGN UP! </a>
</div>
</div>
<div class="col-xs-9">
  <div class="title">ABOUT US</div>
</div>

<div class="col-xs-10 margin-auto text-center"> 
	<p>Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.</p>

    <p>Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.</p> 
</div>

<div class="col-xs-8">
<hr class="border">
<div class="col-xs-4">
  <div class="menu">
    <h3>Menu</h3>
   <ul class="nav-menu">
       <li><a href="">A1</a></li>
       <li><a href="">A1</a></li>
       <li><a href="">A1</a></li>
       <li><a href="">A1</a></li>
       <li><a href="">A1</a></li>
       <li><a href="">A1</a></li>
       <li><a href="">A1</a></li>
       <li><a href="">A1</a></li>
   </ul>
  </div>
</div>
<div class="col-xs-8 articcle">
    <div class="col-xs-12 articcle-menu text-center">
      <h3>Main article</h3>
      <a href="#" class="btn-box">ALL ARTICLE</a>
      <a href="#" class="btn-box">MY INTERESTS</a>
    </div> 
    <div class="col-xs-12">
      <p>text will be here. text will be here. text will be here. text will be here. text will be here. text will be here. text will be here. </p> 
      <p>text will be here. text will be here. text will be here. text will be here. text will be here. text will be here. text will be here. </p> 
       <p>text will be here. text will be here. text will be here. text will be here. text will be here. text will be here. text will be here. </p> 
      <a href="#" class="btn-box pull-right">READ MORE</a>
    </div> 
    <div class="col-xs-12 articcle-menu text-center">
      <h3 class="text-left">Subscribers’ posts (?)</h3>
      <a href="#" class="btn-box">ALL POSTS</a>
      <a href="#" class="btn-box">FRIENDS’ POSTS</a>
      <a href="#" class="btn-box">AREA</a>
    </div>
</div>
    <div class="col-xs-4">
      <div class="menu"> 
       <ul class="nav-menu tow">
           <li><a href="#">Jenn</a></li>
           <li><a href="#">David</a></li>
           <li><a href="#">Sarah</a></li> 
       </ul>
      </div>
    </div>
    <div class="col-xs-8">
      <p>text will be here. text will be here. text will be here. text will be here. text will be here. text will be here. text will be here. </p>
    </div>
</div>
<div class="col-xs-4">
<script src="js/sidebar_right.js"></script>
<div class="sidebar_r"> 
        <div class="cal_map"> 
            <div class="calendar">
                <div class="day_names">
                    <div class="week">
                        <div class="day">Sun</div>
                        <div class="day">Mon</div>
                        <div class="day">Tue</div>
                        <div class="day">Wed</div>
                        <div class="day">Thu</div>
                        <div class="day">Fri</div>
                        <div class="day">Sat</div>
                    </div>
                </div>
                <div class="days">
                        <div class="content overlay">
                        <div class="week">
                        <div class="day  ">
                        26                              </div>
                        <div class="day  ">
                        27                              </div>
                        <div class="day  ">
                        28                              </div>
                        <div class="day  ">
                        29                              </div>
                        <div class="day  ">
                        30                              </div>
                        <div class="day this_month ">
                        1                               </div>
                        <div class="day this_month ">
                        2                               </div>
                        </div>
                        <div class="week">
                        <div class="day this_month ">
                        3                               </div>
                        <div class="day this_month low">
                        4                               </div>
                        <div class="day this_month med">
                        5                               </div>
                        <div class="day this_month ">
                        6                               </div>
                        <div class="day this_month high">
                        7                               </div>
                        <div class="day this_month ">
                        8                               </div>
                        <div class="day this_month ">
                        9                               </div>
                        </div>
                        <div class="week">
                        <div class="day this_month ">
                        10                              </div>
                        <div class="day this_month ">
                        11                              </div>
                        <div class="day this_month ">
                        12                              </div>
                        <div class="day this_month ">
                        13                              </div>
                        <div class="day this_month ">
                        14                              </div>
                        <div class="day this_month ">
                        15                              </div>
                        <div class="day this_month ">
                        16                              </div>
                        </div>
                        <div class="week">
                        <div class="day this_month ">
                        17                              </div>
                        <div class="day this_month ">
                        18                              </div>
                        <div class="day this_month ">
                        19                              </div>
                        <div class="day this_month ">
                        20                              </div>
                        <div class="day this_month ">
                        21                              </div>
                        <div class="day this_month ">
                        22                              </div>
                        <div class="day this_month ">
                        23                              </div>
                        </div>
                        <div class="week">
                        <div class="day this_month ">
                        24                              </div>
                        <div class="day this_month ">
                        25                              </div>
                        <div class="day this_month ">
                        26                              </div>
                        <div class="day this_month ">
                        27                              </div>
                        <div class="day this_month ">
                        28                              </div>
                        <div class="day this_month ">
                        29                              </div>
                        <div class="day this_month ">
                        30                              </div>
                        </div>
                        </div>
                </div>
            </div> 
        </div>
        <div class="row go-right">
        <div class="col-xs-12">
        <iframe width="100%" height="130" src="https://www.youtube.com/embed/E62uSIDb1RU" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen></iframe>
        </div>
        <div class="col-xs-12 ">
           <p> Looking for a travel partner? </p>
           <a href="#" class="btn-box">LET’S GO!</a>
        </div>
        <div class="col-xs-12">
           <p> Want to share some skills? </p>
           <a href="#" class="btn-box">FIND OUT MORE!</a>
        </div>
        </div>
    </div>

</div>
        <div class="col-xs-12 text-right"> 
           <a href="#" class="btn-box">HELP US IMPROVE!</a>
        </div>
  
</div>
</form>

<style type="text/css">
    
.sidebar_r .calendar .days {
    width: 100%;
    height: 0;
    padding: 50% 0 0 0;
    position: relative;
}

.sidebar_r .calendar .days .content {
    position: absolute;
    top: 0;
    left: 0;
}

.sidebar_r .calendar .day {
    display: inline-block;
    width: 14.28571%;
    height: 100%;
    text-align: right;
    font-size: 10px;
    position: relative;
    padding: 2%;
    background-color: #eee;
}
.sidebar_r .calendar .day.this_month {
    background-color: #fff;
}

.sidebar_r .calendar .day.low {
    background-color: yellow;
}
.sidebar_r .calendar .day.med {
    background-color: orange;
}
.sidebar_r .calendar .day.high {
    background-color: red;
}



.sidebar_r .calendar .week {
    white-space: nowrap;
    font-size: 0;
    position: relative;
    height: 20%;
}


.sidebar_r .calendar .day:not(:first-child),
.sidebar_r .calendar .days .week {
    border: 1px solid #ccc;
}
.sidebar_r .calendar .day:not(:first-child) {
    border-width: 0 0 0 1px;
}
.sidebar_r .calendar .days .week {
    border-width: 1px 0 0 0;
}

.sidebar_r .calendar .day_names .week {
    height: 10%;
}
.sidebar_r .calendar .day_names .day {
    text-align: center;
    border: none;
    padding: 2% 0;
    background-color: #fff;
}
.sidebar_r .calendar {
    border: 1px solid #000;
}
</style>