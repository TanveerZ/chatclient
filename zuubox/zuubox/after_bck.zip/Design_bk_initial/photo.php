<link rel="stylesheet" href="css/post.css">
<form class="profile" method="post" enctype="multipart/form-data">
  
<link rel="stylesheet" href="demo.css">
    <link rel="stylesheet" href="js/dist/jquery.flipster.min.css"> 
    <script src="js/dist/jquery.flipster.min.js"></script>


<article id="demo-default" class="demo"> 

    <div id="coverflow">
        <ul class="flip-items">
            <li data-flip-title="Red">
                <img src="img/img/text1.gif">
            </li>
            <li data-flip-title="Razzmatazz" data-flip-category="Purples">
                <img src="img/img/text2.gif">
             </li>
            <li data-flip-title="Deep Lilac" data-flip-category="Purples">
                <img src="img/img/text3.gif">
            </li>
            <li data-flip-title="Daisy Bush" data-flip-category="Purples">
                <img src="img/img/text4.gif">
            </li>
            <li data-flip-title="Cerulean Blue" data-flip-category="Blues">
                <img src="img/img/text5.gif">
            </li>
            <li data-flip-title="Dodger Blue" data-flip-category="Blues">
                <img src="img/img/text6.gif">
            </li>
            <li data-flip-title="Cyan" data-flip-category="Blues">
                <img src="img/img/text7.gif">
            </li>
            <li data-flip-title="Robin's Egg" data-flip-category="Blues">
                <img src="img/img/text8.gif">
            </li>
            <li data-flip-title="Deep Sea" data-flip-category="Greens">
                <img src="img/img/text9.gif">
            </li>
            <li data-flip-title="Apple" data-flip-category="Greens">
                <img src="img/img/text10.gif">
            </li>
        </ul>
    </div>

<script>
    var coverflow = $("#coverflow").flipster();
</script>
 
</article>
</form>

