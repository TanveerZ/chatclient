<form class="login_box center" method="post" action="oh.php">
    <div class="login">
		<div class="title">Please Log In</div>
		<div class="underline"></div>
			<label>
			Username
			<input type="text" name="username" class="textinput">
			</label>
			<label>
			Password
			<input type="password" name="password" class="textinput">
			</label> 
		    <input type="submit" value="Login" class="submit">
		    <div class="forgot">
		    <a href="#" class="btn-user"> Forgot Username</a>
		    <a href="#" class="btn-pass"> Forget Password</a> 
		    </div>
	</div>	 
	<div class="username">
		<div class="title">Forgot Username</div>
		<div class="underline"></div>
			<label>
			Email
			<input type="text" name="email" class="textinput">
			</label> 
		    <input type="submit" value="Send" class="submit">
		    <div class="forgot">
		    <a href="#" class="btn-login"> Back to login</a>
		    <a href="#" class="btn-pass"> Forget Password</a> 
		    </div>
	</div>  
	<div class="password">
		<div class="title">Forget Password</div>
		<div class="underline"></div>
			<label>
			Email
			<input type="text" name="email" class="textinput">
			</label> 
		    <input type="submit" value="Send" class="submit">
		    <div class="forgot">
		    <a href="#" class="btn-login"> Back to login</a> 
		    <a href="#" class="btn-user"> Forgot Username</a>
		</div>
	</div> 
</form>



