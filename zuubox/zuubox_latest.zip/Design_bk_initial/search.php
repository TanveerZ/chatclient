<form class="search center" action="#">
			<div class="left">
				<input type="text" class="query">
			</div>
			<div class="right">
				<button type="submit" value="Search" class="submit">
					<div class="top"></div>
					<div class="mid">
						<div class="left"></div>
						<div class="middle">Search</div>
						<div class="right"></div>
					</div>
					<div class="bottom"></div>
					<div class="bottom2"></div>
				</button>
			</div>
		</form>