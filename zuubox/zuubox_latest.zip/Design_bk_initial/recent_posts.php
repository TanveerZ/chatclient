<link rel="stylesheet" href="css/recent_posts.css">
<form class="recent_posts" method="post" enctype="multipart/form-data">
<div class="recent-box-sc">

    <div class="post-left">
	    <div class="user-head">
	    	<h3 class="title">In 7 second will show you what you missed since the last time you logged in.</h3> 
	    	<h4>NEWS</h4>
	    </div>

		<div class="post-viwe">  
		   <p>Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.</p> 
           <p>Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.</p> 
		</div> 

		<div class="post-viwe">  
		   <p>Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.</p> 
           <p>Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.</p> 
		</div>

		<div class="post-viwe">  
		   <p>Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.</p> 
           <p>Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.</p> 
		</div>

		<div class="post-viwe">  
		   <p>Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.</p> 
           <p>Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.Information will be here.</p> 
		</div>
	</div>
	 
 </div>  
</form>


